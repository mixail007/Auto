﻿namespace GaikovBSUIR
{
    partial class OrderNewForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Telerik.WinControls.UI.TableViewDefinition tableViewDefinition1 = new Telerik.WinControls.UI.TableViewDefinition();
            Telerik.WinControls.UI.TableViewDefinition tableViewDefinition2 = new Telerik.WinControls.UI.TableViewDefinition();
            Telerik.WinControls.UI.TableViewDefinition tableViewDefinition3 = new Telerik.WinControls.UI.TableViewDefinition();
            Telerik.WinControls.UI.TableViewDefinition tableViewDefinition4 = new Telerik.WinControls.UI.TableViewDefinition();
            Telerik.WinControls.UI.TableViewDefinition tableViewDefinition5 = new Telerik.WinControls.UI.TableViewDefinition();
            Telerik.WinControls.UI.TableViewDefinition tableViewDefinition6 = new Telerik.WinControls.UI.TableViewDefinition();
            Telerik.WinControls.UI.TableViewDefinition tableViewDefinition7 = new Telerik.WinControls.UI.TableViewDefinition();
            Telerik.WinControls.UI.TableViewDefinition tableViewDefinition8 = new Telerik.WinControls.UI.TableViewDefinition();
            this.radMultiColumnComboBoxOrg = new Telerik.WinControls.UI.RadMultiColumnComboBox();
            this.radMultiColumnComboBoxKontragent = new Telerik.WinControls.UI.RadMultiColumnComboBox();
            this.radButtonSave = new Telerik.WinControls.UI.RadButton();
            this.radMultiColumnComboBoxAuto = new Telerik.WinControls.UI.RadMultiColumnComboBox();
            this.radLabel1 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel2 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel3 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel4 = new Telerik.WinControls.UI.RadLabel();
            this.radMultiColumnComboBoxDogovor = new Telerik.WinControls.UI.RadMultiColumnComboBox();
            this.radLabel5 = new Telerik.WinControls.UI.RadLabel();
            this.Naimenovanie = new Telerik.WinControls.UI.RadTextBox();
            this.radLabel6 = new Telerik.WinControls.UI.RadLabel();
            this.radMultiColumnComboBoxValuta = new Telerik.WinControls.UI.RadMultiColumnComboBox();
            this.radLabel7 = new Telerik.WinControls.UI.RadLabel();
            this.radMultiColumnComboBoxTipCen = new Telerik.WinControls.UI.RadMultiColumnComboBox();
            this.radLabel8 = new Telerik.WinControls.UI.RadLabel();
            this.radDateTimePickerDataCr = new Telerik.WinControls.UI.RadDateTimePicker();
            this.radLabel9 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel10 = new Telerik.WinControls.UI.RadLabel();
            this.radMultiColumnComboBoxTipZakaza = new Telerik.WinControls.UI.RadMultiColumnComboBox();
            this.radLabel11 = new Telerik.WinControls.UI.RadLabel();
            this.radDateTimePickerSrok = new Telerik.WinControls.UI.RadDateTimePicker();
            this.radLabel12 = new Telerik.WinControls.UI.RadLabel();
            this.Manager = new Telerik.WinControls.UI.RadTextBox();
            this.radLabel13 = new Telerik.WinControls.UI.RadLabel();
            this.VidOplaty = new Telerik.WinControls.UI.RadTextBox();
            this.radSpinEditorKurs = new Telerik.WinControls.UI.RadSpinEditor();
            this.radLabel14 = new Telerik.WinControls.UI.RadLabel();
            this.radDateTimePickerСрокПоставки = new Telerik.WinControls.UI.RadDateTimePicker();
            this.radLabel15 = new Telerik.WinControls.UI.RadLabel();
            this.radSpinEditorSumma = new Telerik.WinControls.UI.RadSpinEditor();
            this.radLabel16 = new Telerik.WinControls.UI.RadLabel();
            this.radSpinEditorSumPredoplaty = new Telerik.WinControls.UI.RadSpinEditor();
            this.radLabel17 = new Telerik.WinControls.UI.RadLabel();
            this.radTextBoxAvtor = new Telerik.WinControls.UI.RadTextBox();
            this.radGridView1 = new Telerik.WinControls.UI.RadGridView();
            this.radButton2 = new Telerik.WinControls.UI.RadButton();
            this.radButtonUpdate = new Telerik.WinControls.UI.RadButton();
            ((System.ComponentModel.ISupportInitialize)(this.radMultiColumnComboBoxOrg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radMultiColumnComboBoxOrg.EditorControl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radMultiColumnComboBoxOrg.EditorControl.MasterTemplate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radMultiColumnComboBoxKontragent)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radMultiColumnComboBoxKontragent.EditorControl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radMultiColumnComboBoxKontragent.EditorControl.MasterTemplate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radButtonSave)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radMultiColumnComboBoxAuto)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radMultiColumnComboBoxAuto.EditorControl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radMultiColumnComboBoxAuto.EditorControl.MasterTemplate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radMultiColumnComboBoxDogovor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radMultiColumnComboBoxDogovor.EditorControl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radMultiColumnComboBoxDogovor.EditorControl.MasterTemplate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Naimenovanie)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radMultiColumnComboBoxValuta)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radMultiColumnComboBoxValuta.EditorControl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radMultiColumnComboBoxValuta.EditorControl.MasterTemplate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radMultiColumnComboBoxTipCen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radMultiColumnComboBoxTipCen.EditorControl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radMultiColumnComboBoxTipCen.EditorControl.MasterTemplate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radDateTimePickerDataCr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radMultiColumnComboBoxTipZakaza)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radMultiColumnComboBoxTipZakaza.EditorControl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radMultiColumnComboBoxTipZakaza.EditorControl.MasterTemplate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radDateTimePickerSrok)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Manager)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.VidOplaty)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radSpinEditorKurs)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radDateTimePickerСрокПоставки)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radSpinEditorSumma)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radSpinEditorSumPredoplaty)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radTextBoxAvtor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGridView1.MasterTemplate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radButton2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radButtonUpdate)).BeginInit();
            this.SuspendLayout();
            // 
            // radMultiColumnComboBoxOrg
            // 
            this.radMultiColumnComboBoxOrg.AutoSize = true;
            this.radMultiColumnComboBoxOrg.AutoSizeDropDownHeight = true;
            this.radMultiColumnComboBoxOrg.AutoSizeDropDownToBestFit = true;
            this.radMultiColumnComboBoxOrg.DropDownStyle = Telerik.WinControls.RadDropDownStyle.DropDownList;
            // 
            // radMultiColumnComboBoxOrg.NestedRadGridView
            // 
            this.radMultiColumnComboBoxOrg.EditorControl.BackColor = System.Drawing.SystemColors.Window;
            this.radMultiColumnComboBoxOrg.EditorControl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.radMultiColumnComboBoxOrg.EditorControl.ForeColor = System.Drawing.SystemColors.ControlText;
            this.radMultiColumnComboBoxOrg.EditorControl.Location = new System.Drawing.Point(0, 0);
            // 
            // 
            // 
            this.radMultiColumnComboBoxOrg.EditorControl.MasterTemplate.AllowAddNewRow = false;
            this.radMultiColumnComboBoxOrg.EditorControl.MasterTemplate.AllowCellContextMenu = false;
            this.radMultiColumnComboBoxOrg.EditorControl.MasterTemplate.AllowColumnChooser = false;
            this.radMultiColumnComboBoxOrg.EditorControl.MasterTemplate.AllowDeleteRow = false;
            this.radMultiColumnComboBoxOrg.EditorControl.MasterTemplate.EnableGrouping = false;
            this.radMultiColumnComboBoxOrg.EditorControl.MasterTemplate.ShowFilteringRow = false;
            this.radMultiColumnComboBoxOrg.EditorControl.MasterTemplate.ViewDefinition = tableViewDefinition1;
            this.radMultiColumnComboBoxOrg.EditorControl.Name = "NestedRadGridView";
            this.radMultiColumnComboBoxOrg.EditorControl.ReadOnly = true;
            this.radMultiColumnComboBoxOrg.EditorControl.ShowGroupPanel = false;
            this.radMultiColumnComboBoxOrg.EditorControl.Size = new System.Drawing.Size(240, 150);
            this.radMultiColumnComboBoxOrg.EditorControl.TabIndex = 0;
            this.radMultiColumnComboBoxOrg.Location = new System.Drawing.Point(117, 85);
            this.radMultiColumnComboBoxOrg.Name = "radMultiColumnComboBoxOrg";
            this.radMultiColumnComboBoxOrg.Size = new System.Drawing.Size(239, 20);
            this.radMultiColumnComboBoxOrg.TabIndex = 0;
            this.radMultiColumnComboBoxOrg.TabStop = false;
            // 
            // radMultiColumnComboBoxKontragent
            // 
            this.radMultiColumnComboBoxKontragent.AutoSize = true;
            this.radMultiColumnComboBoxKontragent.AutoSizeDropDownHeight = true;
            this.radMultiColumnComboBoxKontragent.AutoSizeDropDownToBestFit = true;
            this.radMultiColumnComboBoxKontragent.DropDownStyle = Telerik.WinControls.RadDropDownStyle.DropDownList;
            // 
            // radMultiColumnComboBoxKontragent.NestedRadGridView
            // 
            this.radMultiColumnComboBoxKontragent.EditorControl.BackColor = System.Drawing.SystemColors.Window;
            this.radMultiColumnComboBoxKontragent.EditorControl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.radMultiColumnComboBoxKontragent.EditorControl.ForeColor = System.Drawing.SystemColors.ControlText;
            this.radMultiColumnComboBoxKontragent.EditorControl.Location = new System.Drawing.Point(0, 0);
            // 
            // 
            // 
            this.radMultiColumnComboBoxKontragent.EditorControl.MasterTemplate.AllowAddNewRow = false;
            this.radMultiColumnComboBoxKontragent.EditorControl.MasterTemplate.AllowCellContextMenu = false;
            this.radMultiColumnComboBoxKontragent.EditorControl.MasterTemplate.AllowColumnChooser = false;
            this.radMultiColumnComboBoxKontragent.EditorControl.MasterTemplate.AllowDeleteRow = false;
            this.radMultiColumnComboBoxKontragent.EditorControl.MasterTemplate.EnableGrouping = false;
            this.radMultiColumnComboBoxKontragent.EditorControl.MasterTemplate.ShowFilteringRow = false;
            this.radMultiColumnComboBoxKontragent.EditorControl.MasterTemplate.ViewDefinition = tableViewDefinition2;
            this.radMultiColumnComboBoxKontragent.EditorControl.Name = "NestedRadGridView";
            this.radMultiColumnComboBoxKontragent.EditorControl.ReadOnly = true;
            this.radMultiColumnComboBoxKontragent.EditorControl.ShowGroupPanel = false;
            this.radMultiColumnComboBoxKontragent.EditorControl.Size = new System.Drawing.Size(240, 150);
            this.radMultiColumnComboBoxKontragent.EditorControl.TabIndex = 0;
            this.radMultiColumnComboBoxKontragent.Location = new System.Drawing.Point(116, 53);
            this.radMultiColumnComboBoxKontragent.Name = "radMultiColumnComboBoxKontragent";
            this.radMultiColumnComboBoxKontragent.Size = new System.Drawing.Size(240, 20);
            this.radMultiColumnComboBoxKontragent.TabIndex = 1;
            this.radMultiColumnComboBoxKontragent.TabStop = false;
            // 
            // radButtonSave
            // 
            this.radButtonSave.Location = new System.Drawing.Point(415, 473);
            this.radButtonSave.Name = "radButtonSave";
            this.radButtonSave.Size = new System.Drawing.Size(162, 26);
            this.radButtonSave.TabIndex = 2;
            this.radButtonSave.Text = "Сохранить";
            this.radButtonSave.Click += new System.EventHandler(this.RadButton1Click);
            // 
            // radMultiColumnComboBoxAuto
            // 
            this.radMultiColumnComboBoxAuto.AutoSize = true;
            this.radMultiColumnComboBoxAuto.AutoSizeDropDownHeight = true;
            this.radMultiColumnComboBoxAuto.AutoSizeDropDownToBestFit = true;
            this.radMultiColumnComboBoxAuto.DropDownStyle = Telerik.WinControls.RadDropDownStyle.DropDownList;
            // 
            // radMultiColumnComboBoxAuto.NestedRadGridView
            // 
            this.radMultiColumnComboBoxAuto.EditorControl.BackColor = System.Drawing.SystemColors.Window;
            this.radMultiColumnComboBoxAuto.EditorControl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.radMultiColumnComboBoxAuto.EditorControl.ForeColor = System.Drawing.SystemColors.ControlText;
            this.radMultiColumnComboBoxAuto.EditorControl.Location = new System.Drawing.Point(0, 0);
            // 
            // 
            // 
            this.radMultiColumnComboBoxAuto.EditorControl.MasterTemplate.AllowAddNewRow = false;
            this.radMultiColumnComboBoxAuto.EditorControl.MasterTemplate.AllowCellContextMenu = false;
            this.radMultiColumnComboBoxAuto.EditorControl.MasterTemplate.AllowColumnChooser = false;
            this.radMultiColumnComboBoxAuto.EditorControl.MasterTemplate.AllowDeleteRow = false;
            this.radMultiColumnComboBoxAuto.EditorControl.MasterTemplate.EnableGrouping = false;
            this.radMultiColumnComboBoxAuto.EditorControl.MasterTemplate.ShowFilteringRow = false;
            this.radMultiColumnComboBoxAuto.EditorControl.MasterTemplate.ViewDefinition = tableViewDefinition3;
            this.radMultiColumnComboBoxAuto.EditorControl.Name = "NestedRadGridView";
            this.radMultiColumnComboBoxAuto.EditorControl.ReadOnly = true;
            this.radMultiColumnComboBoxAuto.EditorControl.ShowGroupPanel = false;
            this.radMultiColumnComboBoxAuto.EditorControl.Size = new System.Drawing.Size(240, 150);
            this.radMultiColumnComboBoxAuto.EditorControl.TabIndex = 0;
            this.radMultiColumnComboBoxAuto.Location = new System.Drawing.Point(117, 121);
            this.radMultiColumnComboBoxAuto.Name = "radMultiColumnComboBoxAuto";
            this.radMultiColumnComboBoxAuto.Size = new System.Drawing.Size(240, 20);
            this.radMultiColumnComboBoxAuto.TabIndex = 3;
            this.radMultiColumnComboBoxAuto.TabStop = false;
            this.radMultiColumnComboBoxAuto.UseCompatibleTextRendering = false;
            // 
            // radLabel1
            // 
            this.radLabel1.Location = new System.Drawing.Point(28, 51);
            this.radLabel1.Name = "radLabel1";
            this.radLabel1.Size = new System.Drawing.Size(64, 18);
            this.radLabel1.TabIndex = 4;
            this.radLabel1.Text = "Контрагент";
            // 
            // radLabel2
            // 
            this.radLabel2.Location = new System.Drawing.Point(28, 85);
            this.radLabel2.Name = "radLabel2";
            this.radLabel2.Size = new System.Drawing.Size(74, 18);
            this.radLabel2.TabIndex = 5;
            this.radLabel2.Text = "Организация";
            // 
            // radLabel3
            // 
            this.radLabel3.Location = new System.Drawing.Point(28, 123);
            this.radLabel3.Name = "radLabel3";
            this.radLabel3.Size = new System.Drawing.Size(70, 18);
            this.radLabel3.TabIndex = 5;
            this.radLabel3.Text = "Автомобиль";
            // 
            // radLabel4
            // 
            this.radLabel4.Location = new System.Drawing.Point(27, 154);
            this.radLabel4.Name = "radLabel4";
            this.radLabel4.Size = new System.Drawing.Size(51, 18);
            this.radLabel4.TabIndex = 6;
            this.radLabel4.Text = "Договор";
            // 
            // radMultiColumnComboBoxDogovor
            // 
            this.radMultiColumnComboBoxDogovor.AutoSize = true;
            this.radMultiColumnComboBoxDogovor.AutoSizeDropDownHeight = true;
            this.radMultiColumnComboBoxDogovor.AutoSizeDropDownToBestFit = true;
            this.radMultiColumnComboBoxDogovor.DropDownStyle = Telerik.WinControls.RadDropDownStyle.DropDownList;
            // 
            // radMultiColumnComboBoxDogovor.NestedRadGridView
            // 
            this.radMultiColumnComboBoxDogovor.EditorControl.BackColor = System.Drawing.SystemColors.Window;
            this.radMultiColumnComboBoxDogovor.EditorControl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.radMultiColumnComboBoxDogovor.EditorControl.ForeColor = System.Drawing.SystemColors.ControlText;
            this.radMultiColumnComboBoxDogovor.EditorControl.Location = new System.Drawing.Point(0, 0);
            // 
            // 
            // 
            this.radMultiColumnComboBoxDogovor.EditorControl.MasterTemplate.AllowAddNewRow = false;
            this.radMultiColumnComboBoxDogovor.EditorControl.MasterTemplate.AllowCellContextMenu = false;
            this.radMultiColumnComboBoxDogovor.EditorControl.MasterTemplate.AllowColumnChooser = false;
            this.radMultiColumnComboBoxDogovor.EditorControl.MasterTemplate.AllowDeleteRow = false;
            this.radMultiColumnComboBoxDogovor.EditorControl.MasterTemplate.EnableGrouping = false;
            this.radMultiColumnComboBoxDogovor.EditorControl.MasterTemplate.ShowFilteringRow = false;
            this.radMultiColumnComboBoxDogovor.EditorControl.MasterTemplate.ViewDefinition = tableViewDefinition4;
            this.radMultiColumnComboBoxDogovor.EditorControl.Name = "NestedRadGridView";
            this.radMultiColumnComboBoxDogovor.EditorControl.ReadOnly = true;
            this.radMultiColumnComboBoxDogovor.EditorControl.ShowGroupPanel = false;
            this.radMultiColumnComboBoxDogovor.EditorControl.Size = new System.Drawing.Size(240, 150);
            this.radMultiColumnComboBoxDogovor.EditorControl.TabIndex = 0;
            this.radMultiColumnComboBoxDogovor.Location = new System.Drawing.Point(117, 154);
            this.radMultiColumnComboBoxDogovor.Name = "radMultiColumnComboBoxDogovor";
            this.radMultiColumnComboBoxDogovor.Size = new System.Drawing.Size(240, 20);
            this.radMultiColumnComboBoxDogovor.TabIndex = 7;
            this.radMultiColumnComboBoxDogovor.TabStop = false;
            this.radMultiColumnComboBoxDogovor.UseCompatibleTextRendering = false;
            // 
            // radLabel5
            // 
            this.radLabel5.Location = new System.Drawing.Point(26, 13);
            this.radLabel5.Name = "radLabel5";
            this.radLabel5.Size = new System.Drawing.Size(84, 18);
            this.radLabel5.TabIndex = 4;
            this.radLabel5.Text = "Наименование";
            // 
            // Naimenovanie
            // 
            this.Naimenovanie.Location = new System.Drawing.Point(116, 13);
            this.Naimenovanie.Name = "Naimenovanie";
            this.Naimenovanie.Size = new System.Drawing.Size(240, 20);
            this.Naimenovanie.TabIndex = 8;
            // 
            // radLabel6
            // 
            this.radLabel6.Location = new System.Drawing.Point(27, 186);
            this.radLabel6.Name = "radLabel6";
            this.radLabel6.Size = new System.Drawing.Size(44, 18);
            this.radLabel6.TabIndex = 6;
            this.radLabel6.Text = "Валюта";
            // 
            // radMultiColumnComboBoxValuta
            // 
            this.radMultiColumnComboBoxValuta.AutoSize = true;
            this.radMultiColumnComboBoxValuta.AutoSizeDropDownHeight = true;
            this.radMultiColumnComboBoxValuta.AutoSizeDropDownToBestFit = true;
            this.radMultiColumnComboBoxValuta.DropDownStyle = Telerik.WinControls.RadDropDownStyle.DropDownList;
            // 
            // radMultiColumnComboBoxValuta.NestedRadGridView
            // 
            this.radMultiColumnComboBoxValuta.EditorControl.BackColor = System.Drawing.SystemColors.Window;
            this.radMultiColumnComboBoxValuta.EditorControl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.radMultiColumnComboBoxValuta.EditorControl.ForeColor = System.Drawing.SystemColors.ControlText;
            this.radMultiColumnComboBoxValuta.EditorControl.Location = new System.Drawing.Point(0, 0);
            // 
            // 
            // 
            this.radMultiColumnComboBoxValuta.EditorControl.MasterTemplate.AllowAddNewRow = false;
            this.radMultiColumnComboBoxValuta.EditorControl.MasterTemplate.AllowCellContextMenu = false;
            this.radMultiColumnComboBoxValuta.EditorControl.MasterTemplate.AllowColumnChooser = false;
            this.radMultiColumnComboBoxValuta.EditorControl.MasterTemplate.AllowDeleteRow = false;
            this.radMultiColumnComboBoxValuta.EditorControl.MasterTemplate.EnableGrouping = false;
            this.radMultiColumnComboBoxValuta.EditorControl.MasterTemplate.ShowFilteringRow = false;
            this.radMultiColumnComboBoxValuta.EditorControl.MasterTemplate.ViewDefinition = tableViewDefinition5;
            this.radMultiColumnComboBoxValuta.EditorControl.Name = "NestedRadGridView";
            this.radMultiColumnComboBoxValuta.EditorControl.ReadOnly = true;
            this.radMultiColumnComboBoxValuta.EditorControl.ShowGroupPanel = false;
            this.radMultiColumnComboBoxValuta.EditorControl.Size = new System.Drawing.Size(240, 150);
            this.radMultiColumnComboBoxValuta.EditorControl.TabIndex = 0;
            this.radMultiColumnComboBoxValuta.Location = new System.Drawing.Point(117, 185);
            this.radMultiColumnComboBoxValuta.Name = "radMultiColumnComboBoxValuta";
            this.radMultiColumnComboBoxValuta.Size = new System.Drawing.Size(240, 20);
            this.radMultiColumnComboBoxValuta.TabIndex = 7;
            this.radMultiColumnComboBoxValuta.TabStop = false;
            this.radMultiColumnComboBoxValuta.UseCompatibleTextRendering = false;
            // 
            // radLabel7
            // 
            this.radLabel7.Location = new System.Drawing.Point(420, 16);
            this.radLabel7.Name = "radLabel7";
            this.radLabel7.Size = new System.Drawing.Size(56, 18);
            this.radLabel7.TabIndex = 6;
            this.radLabel7.Text = "Тип цены";
            // 
            // radMultiColumnComboBoxTipCen
            // 
            this.radMultiColumnComboBoxTipCen.AutoSize = true;
            this.radMultiColumnComboBoxTipCen.AutoSizeDropDownHeight = true;
            this.radMultiColumnComboBoxTipCen.AutoSizeDropDownToBestFit = true;
            this.radMultiColumnComboBoxTipCen.DropDownStyle = Telerik.WinControls.RadDropDownStyle.DropDownList;
            // 
            // radMultiColumnComboBoxTipCen.NestedRadGridView
            // 
            this.radMultiColumnComboBoxTipCen.EditorControl.BackColor = System.Drawing.SystemColors.Window;
            this.radMultiColumnComboBoxTipCen.EditorControl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.radMultiColumnComboBoxTipCen.EditorControl.ForeColor = System.Drawing.SystemColors.ControlText;
            this.radMultiColumnComboBoxTipCen.EditorControl.Location = new System.Drawing.Point(0, 0);
            // 
            // 
            // 
            this.radMultiColumnComboBoxTipCen.EditorControl.MasterTemplate.AllowAddNewRow = false;
            this.radMultiColumnComboBoxTipCen.EditorControl.MasterTemplate.AllowCellContextMenu = false;
            this.radMultiColumnComboBoxTipCen.EditorControl.MasterTemplate.AllowColumnChooser = false;
            this.radMultiColumnComboBoxTipCen.EditorControl.MasterTemplate.AllowDeleteRow = false;
            this.radMultiColumnComboBoxTipCen.EditorControl.MasterTemplate.EnableGrouping = false;
            this.radMultiColumnComboBoxTipCen.EditorControl.MasterTemplate.ShowFilteringRow = false;
            this.radMultiColumnComboBoxTipCen.EditorControl.MasterTemplate.ViewDefinition = tableViewDefinition6;
            this.radMultiColumnComboBoxTipCen.EditorControl.Name = "NestedRadGridView";
            this.radMultiColumnComboBoxTipCen.EditorControl.ReadOnly = true;
            this.radMultiColumnComboBoxTipCen.EditorControl.ShowGroupPanel = false;
            this.radMultiColumnComboBoxTipCen.EditorControl.Size = new System.Drawing.Size(240, 150);
            this.radMultiColumnComboBoxTipCen.EditorControl.TabIndex = 0;
            this.radMultiColumnComboBoxTipCen.Location = new System.Drawing.Point(505, 15);
            this.radMultiColumnComboBoxTipCen.Name = "radMultiColumnComboBoxTipCen";
            this.radMultiColumnComboBoxTipCen.Size = new System.Drawing.Size(233, 20);
            this.radMultiColumnComboBoxTipCen.TabIndex = 7;
            this.radMultiColumnComboBoxTipCen.TabStop = false;
            this.radMultiColumnComboBoxTipCen.UseCompatibleTextRendering = false;
            // 
            // radLabel8
            // 
            this.radLabel8.Location = new System.Drawing.Point(27, 221);
            this.radLabel8.Name = "radLabel8";
            this.radLabel8.Size = new System.Drawing.Size(30, 18);
            this.radLabel8.TabIndex = 6;
            this.radLabel8.Text = "Курс";
            // 
            // radDateTimePickerDataCr
            // 
            this.radDateTimePickerDataCr.Location = new System.Drawing.Point(509, 185);
            this.radDateTimePickerDataCr.Name = "radDateTimePickerDataCr";
            this.radDateTimePickerDataCr.Size = new System.Drawing.Size(229, 20);
            this.radDateTimePickerDataCr.TabIndex = 9;
            this.radDateTimePickerDataCr.TabStop = false;
            this.radDateTimePickerDataCr.Value = new System.DateTime(((long)(0)));
            // 
            // radLabel9
            // 
            this.radLabel9.Location = new System.Drawing.Point(421, 186);
            this.radLabel9.Name = "radLabel9";
            this.radLabel9.Size = new System.Drawing.Size(81, 18);
            this.radLabel9.TabIndex = 6;
            this.radLabel9.Text = "Дата создания";
            // 
            // radLabel10
            // 
            this.radLabel10.Location = new System.Drawing.Point(421, 52);
            this.radLabel10.Name = "radLabel10";
            this.radLabel10.Size = new System.Drawing.Size(61, 18);
            this.radLabel10.TabIndex = 6;
            this.radLabel10.Text = "Тип заказа";
            // 
            // radMultiColumnComboBoxTipZakaza
            // 
            this.radMultiColumnComboBoxTipZakaza.AutoSize = true;
            this.radMultiColumnComboBoxTipZakaza.AutoSizeDropDownHeight = true;
            this.radMultiColumnComboBoxTipZakaza.AutoSizeDropDownToBestFit = true;
            this.radMultiColumnComboBoxTipZakaza.DropDownStyle = Telerik.WinControls.RadDropDownStyle.DropDownList;
            // 
            // radMultiColumnComboBoxTipZakaza.NestedRadGridView
            // 
            this.radMultiColumnComboBoxTipZakaza.EditorControl.BackColor = System.Drawing.SystemColors.Window;
            this.radMultiColumnComboBoxTipZakaza.EditorControl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.radMultiColumnComboBoxTipZakaza.EditorControl.ForeColor = System.Drawing.SystemColors.ControlText;
            this.radMultiColumnComboBoxTipZakaza.EditorControl.Location = new System.Drawing.Point(0, 0);
            // 
            // 
            // 
            this.radMultiColumnComboBoxTipZakaza.EditorControl.MasterTemplate.AllowAddNewRow = false;
            this.radMultiColumnComboBoxTipZakaza.EditorControl.MasterTemplate.AllowCellContextMenu = false;
            this.radMultiColumnComboBoxTipZakaza.EditorControl.MasterTemplate.AllowColumnChooser = false;
            this.radMultiColumnComboBoxTipZakaza.EditorControl.MasterTemplate.AllowDeleteRow = false;
            this.radMultiColumnComboBoxTipZakaza.EditorControl.MasterTemplate.EnableGrouping = false;
            this.radMultiColumnComboBoxTipZakaza.EditorControl.MasterTemplate.ShowFilteringRow = false;
            this.radMultiColumnComboBoxTipZakaza.EditorControl.MasterTemplate.ViewDefinition = tableViewDefinition7;
            this.radMultiColumnComboBoxTipZakaza.EditorControl.Name = "NestedRadGridView";
            this.radMultiColumnComboBoxTipZakaza.EditorControl.ReadOnly = true;
            this.radMultiColumnComboBoxTipZakaza.EditorControl.ShowGroupPanel = false;
            this.radMultiColumnComboBoxTipZakaza.EditorControl.Size = new System.Drawing.Size(240, 150);
            this.radMultiColumnComboBoxTipZakaza.EditorControl.TabIndex = 0;
            this.radMultiColumnComboBoxTipZakaza.Location = new System.Drawing.Point(506, 50);
            this.radMultiColumnComboBoxTipZakaza.Name = "radMultiColumnComboBoxTipZakaza";
            this.radMultiColumnComboBoxTipZakaza.Size = new System.Drawing.Size(233, 20);
            this.radMultiColumnComboBoxTipZakaza.TabIndex = 7;
            this.radMultiColumnComboBoxTipZakaza.TabStop = false;
            this.radMultiColumnComboBoxTipZakaza.UseCompatibleTextRendering = false;
            // 
            // radLabel11
            // 
            this.radLabel11.AutoSize = false;
            this.radLabel11.Location = new System.Drawing.Point(420, 210);
            this.radLabel11.Name = "radLabel11";
            this.radLabel11.Size = new System.Drawing.Size(81, 33);
            this.radLabel11.TabIndex = 6;
            this.radLabel11.Text = "Срок снятия с резерва";
            // 
            // radDateTimePickerSrok
            // 
            this.radDateTimePickerSrok.Location = new System.Drawing.Point(508, 217);
            this.radDateTimePickerSrok.Name = "radDateTimePickerSrok";
            this.radDateTimePickerSrok.Size = new System.Drawing.Size(229, 20);
            this.radDateTimePickerSrok.TabIndex = 9;
            this.radDateTimePickerSrok.TabStop = false;
            this.radDateTimePickerSrok.Value = new System.DateTime(((long)(0)));
            // 
            // radLabel12
            // 
            this.radLabel12.Location = new System.Drawing.Point(422, 122);
            this.radLabel12.Name = "radLabel12";
            this.radLabel12.Size = new System.Drawing.Size(62, 18);
            this.radLabel12.TabIndex = 4;
            this.radLabel12.Text = "Менеджер";
            // 
            // Manager
            // 
            this.Manager.Location = new System.Drawing.Point(506, 122);
            this.Manager.Name = "Manager";
            this.Manager.Size = new System.Drawing.Size(233, 20);
            this.Manager.TabIndex = 8;
            // 
            // radLabel13
            // 
            this.radLabel13.Location = new System.Drawing.Point(422, 86);
            this.radLabel13.Name = "radLabel13";
            this.radLabel13.Size = new System.Drawing.Size(66, 18);
            this.radLabel13.TabIndex = 4;
            this.radLabel13.Text = "Вид оплаты";
            // 
            // VidOplaty
            // 
            this.VidOplaty.Location = new System.Drawing.Point(506, 86);
            this.VidOplaty.Name = "VidOplaty";
            this.VidOplaty.Size = new System.Drawing.Size(233, 20);
            this.VidOplaty.TabIndex = 8;
            // 
            // radSpinEditorKurs
            // 
            this.radSpinEditorKurs.DecimalPlaces = 2;
            this.radSpinEditorKurs.Location = new System.Drawing.Point(118, 219);
            this.radSpinEditorKurs.Maximum = new decimal(new int[] {
            1316134911,
            2328,
            0,
            0});
            this.radSpinEditorKurs.Name = "radSpinEditorKurs";
            this.radSpinEditorKurs.Size = new System.Drawing.Size(239, 20);
            this.radSpinEditorKurs.TabIndex = 10;
            this.radSpinEditorKurs.TabStop = false;
            this.radSpinEditorKurs.ThousandsSeparator = true;
            // 
            // radLabel14
            // 
            this.radLabel14.Location = new System.Drawing.Point(421, 155);
            this.radLabel14.Name = "radLabel14";
            this.radLabel14.Size = new System.Drawing.Size(82, 18);
            this.radLabel14.TabIndex = 6;
            this.radLabel14.Text = "Срок поставки";
            // 
            // radDateTimePickerСрокПоставки
            // 
            this.radDateTimePickerСрокПоставки.Location = new System.Drawing.Point(509, 149);
            this.radDateTimePickerСрокПоставки.Name = "radDateTimePickerСрокПоставки";
            this.radDateTimePickerСрокПоставки.Size = new System.Drawing.Size(229, 20);
            this.radDateTimePickerСрокПоставки.TabIndex = 9;
            this.radDateTimePickerСрокПоставки.TabStop = false;
            this.radDateTimePickerСрокПоставки.Value = new System.DateTime(((long)(0)));
            // 
            // radLabel15
            // 
            this.radLabel15.Location = new System.Drawing.Point(27, 258);
            this.radLabel15.Name = "radLabel15";
            this.radLabel15.Size = new System.Drawing.Size(40, 18);
            this.radLabel15.TabIndex = 6;
            this.radLabel15.Text = "Сумма";
            // 
            // radSpinEditorSumma
            // 
            this.radSpinEditorSumma.DecimalPlaces = 2;
            this.radSpinEditorSumma.Location = new System.Drawing.Point(118, 256);
            this.radSpinEditorSumma.Maximum = new decimal(new int[] {
            1874919423,
            2328306,
            0,
            0});
            this.radSpinEditorSumma.Name = "radSpinEditorSumma";
            this.radSpinEditorSumma.Size = new System.Drawing.Size(239, 20);
            this.radSpinEditorSumma.TabIndex = 10;
            this.radSpinEditorSumma.TabStop = false;
            this.radSpinEditorSumma.ThousandsSeparator = true;
            // 
            // radLabel16
            // 
            this.radLabel16.AutoSize = false;
            this.radLabel16.Location = new System.Drawing.Point(421, 247);
            this.radLabel16.Name = "radLabel16";
            this.radLabel16.Size = new System.Drawing.Size(79, 33);
            this.radLabel16.TabIndex = 6;
            this.radLabel16.Text = "Сумма предоплаты";
            // 
            // radSpinEditorSumPredoplaty
            // 
            this.radSpinEditorSumPredoplaty.DecimalPlaces = 2;
            this.radSpinEditorSumPredoplaty.Location = new System.Drawing.Point(508, 252);
            this.radSpinEditorSumPredoplaty.Maximum = new decimal(new int[] {
            1874919423,
            2328306,
            0,
            0});
            this.radSpinEditorSumPredoplaty.Name = "radSpinEditorSumPredoplaty";
            this.radSpinEditorSumPredoplaty.Size = new System.Drawing.Size(232, 20);
            this.radSpinEditorSumPredoplaty.TabIndex = 10;
            this.radSpinEditorSumPredoplaty.TabStop = false;
            this.radSpinEditorSumPredoplaty.ThousandsSeparator = true;
            // 
            // radLabel17
            // 
            this.radLabel17.Location = new System.Drawing.Point(12, 473);
            this.radLabel17.Name = "radLabel17";
            this.radLabel17.Size = new System.Drawing.Size(37, 18);
            this.radLabel17.TabIndex = 4;
            this.radLabel17.Text = "Автор";
            // 
            // radTextBoxAvtor
            // 
            this.radTextBoxAvtor.Location = new System.Drawing.Point(102, 473);
            this.radTextBoxAvtor.Name = "radTextBoxAvtor";
            this.radTextBoxAvtor.Size = new System.Drawing.Size(228, 20);
            this.radTextBoxAvtor.TabIndex = 8;
            // 
            // radGridView1
            // 
            this.radGridView1.Location = new System.Drawing.Point(8, 293);
            // 
            // 
            // 
            this.radGridView1.MasterTemplate.AddNewRowPosition = Telerik.WinControls.UI.SystemRowPosition.Bottom;
            this.radGridView1.MasterTemplate.AllowDragToGroup = false;
            this.radGridView1.MasterTemplate.EnableGrouping = false;
            this.radGridView1.MasterTemplate.ShowFilteringRow = false;
            this.radGridView1.MasterTemplate.ViewDefinition = tableViewDefinition8;
            this.radGridView1.Name = "radGridView1";
            this.radGridView1.Size = new System.Drawing.Size(754, 165);
            this.radGridView1.TabIndex = 11;
            this.radGridView1.Text = "radGridView1";
            // 
            // radButton2
            // 
            this.radButton2.Location = new System.Drawing.Point(591, 473);
            this.radButton2.Name = "radButton2";
            this.radButton2.Size = new System.Drawing.Size(162, 26);
            this.radButton2.TabIndex = 2;
            this.radButton2.Text = "Отмена";
            this.radButton2.Click += new System.EventHandler(this.RadButton2Click);
            // 
            // radButtonUpdate
            // 
            this.radButtonUpdate.Location = new System.Drawing.Point(415, 473);
            this.radButtonUpdate.Name = "radButtonUpdate";
            this.radButtonUpdate.Size = new System.Drawing.Size(162, 26);
            this.radButtonUpdate.TabIndex = 2;
            this.radButtonUpdate.Text = "Обновить";
            this.radButtonUpdate.Visible = false;
            this.radButtonUpdate.Click += new System.EventHandler(this.RadButtonUpdateClick);
            // 
            // OrderNewForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(774, 507);
            this.Controls.Add(this.radGridView1);
            this.Controls.Add(this.radSpinEditorSumPredoplaty);
            this.Controls.Add(this.radSpinEditorSumma);
            this.Controls.Add(this.radSpinEditorKurs);
            this.Controls.Add(this.radDateTimePickerSrok);
            this.Controls.Add(this.radDateTimePickerСрокПоставки);
            this.Controls.Add(this.radDateTimePickerDataCr);
            this.Controls.Add(this.VidOplaty);
            this.Controls.Add(this.Manager);
            this.Controls.Add(this.radTextBoxAvtor);
            this.Controls.Add(this.Naimenovanie);
            this.Controls.Add(this.radMultiColumnComboBoxTipZakaza);
            this.Controls.Add(this.radMultiColumnComboBoxTipCen);
            this.Controls.Add(this.radMultiColumnComboBoxValuta);
            this.Controls.Add(this.radMultiColumnComboBoxDogovor);
            this.Controls.Add(this.radLabel11);
            this.Controls.Add(this.radLabel14);
            this.Controls.Add(this.radLabel9);
            this.Controls.Add(this.radLabel10);
            this.Controls.Add(this.radLabel16);
            this.Controls.Add(this.radLabel15);
            this.Controls.Add(this.radLabel7);
            this.Controls.Add(this.radLabel8);
            this.Controls.Add(this.radLabel6);
            this.Controls.Add(this.radLabel4);
            this.Controls.Add(this.radLabel3);
            this.Controls.Add(this.radLabel2);
            this.Controls.Add(this.radLabel13);
            this.Controls.Add(this.radLabel12);
            this.Controls.Add(this.radLabel17);
            this.Controls.Add(this.radLabel5);
            this.Controls.Add(this.radLabel1);
            this.Controls.Add(this.radMultiColumnComboBoxAuto);
            this.Controls.Add(this.radButton2);
            this.Controls.Add(this.radButtonUpdate);
            this.Controls.Add(this.radButtonSave);
            this.Controls.Add(this.radMultiColumnComboBoxKontragent);
            this.Controls.Add(this.radMultiColumnComboBoxOrg);
            this.Name = "OrderNewForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Новый";
            this.Load += new System.EventHandler(this.OrderNewForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.radMultiColumnComboBoxOrg.EditorControl.MasterTemplate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radMultiColumnComboBoxOrg.EditorControl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radMultiColumnComboBoxOrg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radMultiColumnComboBoxKontragent.EditorControl.MasterTemplate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radMultiColumnComboBoxKontragent.EditorControl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radMultiColumnComboBoxKontragent)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radButtonSave)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radMultiColumnComboBoxAuto.EditorControl.MasterTemplate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radMultiColumnComboBoxAuto.EditorControl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radMultiColumnComboBoxAuto)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radMultiColumnComboBoxDogovor.EditorControl.MasterTemplate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radMultiColumnComboBoxDogovor.EditorControl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radMultiColumnComboBoxDogovor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Naimenovanie)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radMultiColumnComboBoxValuta.EditorControl.MasterTemplate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radMultiColumnComboBoxValuta.EditorControl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radMultiColumnComboBoxValuta)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radMultiColumnComboBoxTipCen.EditorControl.MasterTemplate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radMultiColumnComboBoxTipCen.EditorControl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radMultiColumnComboBoxTipCen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radDateTimePickerDataCr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radMultiColumnComboBoxTipZakaza.EditorControl.MasterTemplate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radMultiColumnComboBoxTipZakaza.EditorControl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radMultiColumnComboBoxTipZakaza)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radDateTimePickerSrok)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Manager)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.VidOplaty)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radSpinEditorKurs)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radDateTimePickerСрокПоставки)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radSpinEditorSumma)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radSpinEditorSumPredoplaty)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radTextBoxAvtor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGridView1.MasterTemplate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radButton2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radButtonUpdate)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Telerik.WinControls.UI.RadMultiColumnComboBox radMultiColumnComboBoxOrg;
        private Telerik.WinControls.UI.RadMultiColumnComboBox radMultiColumnComboBoxKontragent;
        private Telerik.WinControls.UI.RadButton radButtonSave;
        private Telerik.WinControls.UI.RadMultiColumnComboBox radMultiColumnComboBoxAuto;
        private Telerik.WinControls.UI.RadLabel radLabel1;
        private Telerik.WinControls.UI.RadLabel radLabel2;
        private Telerik.WinControls.UI.RadLabel radLabel3;
        private Telerik.WinControls.UI.RadLabel radLabel4;
        private Telerik.WinControls.UI.RadMultiColumnComboBox radMultiColumnComboBoxDogovor;
        private Telerik.WinControls.UI.RadLabel radLabel5;
        private Telerik.WinControls.UI.RadTextBox Naimenovanie;
        private Telerik.WinControls.UI.RadLabel radLabel6;
        private Telerik.WinControls.UI.RadMultiColumnComboBox radMultiColumnComboBoxValuta;
        private Telerik.WinControls.UI.RadLabel radLabel7;
        private Telerik.WinControls.UI.RadMultiColumnComboBox radMultiColumnComboBoxTipCen;
        private Telerik.WinControls.UI.RadLabel radLabel8;
        private Telerik.WinControls.UI.RadDateTimePicker radDateTimePickerDataCr;
        private Telerik.WinControls.UI.RadLabel radLabel9;
        private Telerik.WinControls.UI.RadLabel radLabel10;
        private Telerik.WinControls.UI.RadMultiColumnComboBox radMultiColumnComboBoxTipZakaza;
        private Telerik.WinControls.UI.RadLabel radLabel11;
        private Telerik.WinControls.UI.RadDateTimePicker radDateTimePickerSrok;
        private Telerik.WinControls.UI.RadLabel radLabel12;
        private Telerik.WinControls.UI.RadTextBox Manager;
        private Telerik.WinControls.UI.RadLabel radLabel13;
        private Telerik.WinControls.UI.RadTextBox VidOplaty;
        private Telerik.WinControls.UI.RadSpinEditor radSpinEditorKurs;
        private Telerik.WinControls.UI.RadLabel radLabel14;
        private Telerik.WinControls.UI.RadDateTimePicker radDateTimePickerСрокПоставки;
        private Telerik.WinControls.UI.RadLabel radLabel15;
        private Telerik.WinControls.UI.RadSpinEditor radSpinEditorSumma;
        private Telerik.WinControls.UI.RadLabel radLabel16;
        private Telerik.WinControls.UI.RadSpinEditor radSpinEditorSumPredoplaty;
        private Telerik.WinControls.UI.RadLabel radLabel17;
        private Telerik.WinControls.UI.RadTextBox radTextBoxAvtor;
        private Telerik.WinControls.UI.RadGridView radGridView1;
        private Telerik.WinControls.UI.RadButton radButton2;
        private Telerik.WinControls.UI.RadButton radButtonUpdate;
    }
}